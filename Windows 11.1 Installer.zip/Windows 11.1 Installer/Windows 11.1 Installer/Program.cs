﻿using System;
using System.Windows.Forms;
using Windows_11._1_Installer;

namespace Forms
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.Run(new Form1()); // This should match your form class name
        }
    }
}

