﻿using System;
using System.Windows.Forms;

namespace Windows_11._1_Installer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult Msg = MessageBox.Show("Do you want to proceed? The setup will not be completed.", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (Msg == DialogResult.OK)
            {
                this.Close();
                if (Msg == DialogResult.Cancel)
                { }
                else { }
            }
        }


        private void Next_Click(object sender, EventArgs e)
        {
            this.Hide();
            License_Agreement license_Agreement = new License_Agreement();
            license_Agreement.Show();
        }
    }
}
