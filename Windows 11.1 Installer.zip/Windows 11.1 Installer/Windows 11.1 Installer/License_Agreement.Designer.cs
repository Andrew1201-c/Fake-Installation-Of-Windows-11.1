﻿namespace Windows_11._1_Installer
{
    partial class License_Agreement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(License_Agreement));
            this.LisenceForm = new System.Windows.Forms.Label();
            this.Cancel = new System.Windows.Forms.Button();
            this.agree = new System.Windows.Forms.Button();
            this.Info = new System.Windows.Forms.Label();
            this.LicenseInfo = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // LisenceForm
            // 
            this.LisenceForm.AutoSize = true;
            this.LisenceForm.Font = new System.Drawing.Font("Microsoft JhengHei Light", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LisenceForm.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.LisenceForm.Location = new System.Drawing.Point(12, 29);
            this.LisenceForm.Name = "LisenceForm";
            this.LisenceForm.Size = new System.Drawing.Size(0, 50);
            this.LisenceForm.TabIndex = 1;
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(30, 540);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(192, 35);
            this.Cancel.TabIndex = 2;
            this.Cancel.Text = "Exit";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // agree
            // 
            this.agree.Location = new System.Drawing.Point(573, 540);
            this.agree.Name = "agree";
            this.agree.Size = new System.Drawing.Size(186, 35);
            this.agree.TabIndex = 3;
            this.agree.TabStop = false;
            this.agree.Text = "Agree";
            this.agree.UseVisualStyleBackColor = true;
            this.agree.Click += new System.EventHandler(this.agree_Click);
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Font = new System.Drawing.Font("Microsoft Tai Le", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Info.ForeColor = System.Drawing.SystemColors.InfoText;
            this.Info.Location = new System.Drawing.Point(16, 95);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(0, 30);
            this.Info.TabIndex = 4;
            // 
            // LicenseInfo
            // 
            this.LicenseInfo.AutoSize = true;
            this.LicenseInfo.Font = new System.Drawing.Font("Microsoft JhengHei Light", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LicenseInfo.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.LicenseInfo.Location = new System.Drawing.Point(18, 29);
            this.LicenseInfo.Name = "LicenseInfo";
            this.LicenseInfo.Size = new System.Drawing.Size(368, 50);
            this.LicenseInfo.TabIndex = 6;
            this.LicenseInfo.Text = "License Agreement";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 16;
            this.listBox1.Items.AddRange(new object[] {
            "",
            "",
            "1. INSTALLATION AND USE RIGHTS.",
            "",
            "Home Use. ",
            "If you are a home user, then you may install and use ",
            "any number of copies of the software on your personal devices for use by people w" +
                "ho reside in your household.",
            "",
            "Small Business. ",
            "If you operate a small business, then you may install and use the software on up " +
                "to ten (10) ",
            "devices in your business.",
            "",
            "Restrictions. ",
            "The software may not be used on devices owned by government or academic instituti" +
                "ons.",
            "",
            "Separation of Components. ",
            "The components of the software are licensed as a single unit. ",
            "You may not separate the components and install them on different devices.",
            "",
            "Included Microsoft Programs. ",
            "The software may contain other Microsoft programs. ",
            "The license terms with those programs apply to your use of them.",
            "",
            "2. INTERNET-BASED SERVICES. ",
            "Microsoft provides Internet-based services with the software. ",
            "It may change or cancel them at any time.",
            "",
            "Consent for Internet-Based Services. ",
            "The software features described below ",
            "and in the Microsoft Security Essentials Privacy Statement connect to Microsoft o" +
                "r service provider computer systems over the Internet. ",
            "In some cases, you will not receive a separate notice when they connect.",
            "In some cases, you may switch off these features or not use them. ",
            "For more information about these features, see http://go.microsoft.com/fwlink/?Li" +
                "nkId=148744. ",
            "By using these features, you consent to the transmission of this information. ",
            "Microsoft does not use the information to identify or contact you.",
            "",
            "1. Computer Information. ",
            "The following features use Internet protocols, which send to the appropriate syst" +
                "ems computer information, ",
            "such as your Internet protocol address, ",
            "the type of operating system, ",
            "browser and name and version of the software you are using, ",
            "and the language code of the device where you installed the software. ",
            "Microsoft uses this information to make the Internet-based services available to " +
                "you.",
            "",
            "Updates.",
            "By default, the software will automatically download definition updates.",
            " For more information, see the privacy statement at http://go.microsoft.com/fwlin" +
                "k/?LinkId=148744.",
            "",
            "Malicious Software Removal. ",
            "The software will check for and remove certain high severity malicious software (" +
                "\"Malware\") ",
            "stored on your device during scheduled scans and when you select this action. Whe" +
                "n the software checks your device for Malware, ",
            "a report will be sent to Microsoft about any Malware detected or errors that occu" +
                "r while the software is checking for Malware, ",
            "specific information relating to the detection,",
            " errors that occurred while the software was checking for Malware,",
            " and other information about your device that will help us improve this and other" +
                " Microsoft products and services. No information that can be used to identify yo" +
                "u is included in the report.",
            "",
            "Potentially Unwanted Software. ",
            "The software will search your computer for low to medium severity Malware, ",
            "including but not limited to, spyware, and other potentially unwanted software (\"" +
                "Potentially Unwanted Software\"). ",
            "The software will only remove or disable low to medium severity Potentially Unwan" +
                "ted Software if you agree. ",
            "Removing or disabling this Potentially Unwanted Software may cause other software" +
                " on your computer to stop working, ",
            "and it may cause you to breach a license to use other software on your computer, " +
                "",
            resources.GetString("listBox1.Items"),
            "",
            resources.GetString("listBox1.Items1"),
            "",
            "Error Reports. ",
            "This software automatically sends error reports to Microsoft that describe which " +
                "software components had errors. ",
            "No files or memory dumps will be sent unless you choose to send them. ",
            "For more information about Error Reports, see http://go.microsoft.com/fwlink/?Lin" +
                "kId=148744.",
            "",
            "Windows Update; Microsoft Update. ",
            "The software turns on automatic updating from Windows Update and Microsoft Update" +
                ". ",
            "To enable the proper functioning of the Windows Update and Microsoft Update servi" +
                "ce in the software, ",
            "updates or downloads to the Windows Update and/or Microsoft Update service will b" +
                "e required from time to time and downloaded and installed without further notice" +
                " to you.",
            "",
            "2. Use of Information. ",
            resources.GetString("listBox1.Items2"),
            "They may use the information to improve how their products run with Microsoft sof" +
                "tware.",
            "",
            "",
            "3. SCOPE OF LICENSE. ",
            "The software is licensed, not sold. ",
            "This agreement only gives you some rights to use the software. ",
            "Microsoft reserves all other rights. Unless applicable law gives you more rights " +
                "despite this limitation, you may use the software only as expressly permitted in" +
                " this agreement. ",
            "In doing so, you must comply with any technical limitations in the software that " +
                "only allow you to use it in certain ways. You may not",
            "",
            "work around any technical limitations in the software;",
            "",
            "reverse engineer, decompile or disassemble the software, except and only to the e" +
                "xtent that applicable law expressly permits, despite this limitation;",
            "",
            "make more copies of the software than specified in this agreement or allowed by a" +
                "pplicable law, despite this limitation;",
            "",
            "publish the software for others to copy;",
            "",
            "rent, lease or lend the software;",
            "",
            "transfer the software or this agreement to any third party; or",
            "",
            "use the software for commercial software hosting services.",
            "",
            "4. BACKUP COPY. ",
            "You may make one backup copy of the software. You may use it only to reinstall th" +
                "e software.",
            "",
            "5. DOCUMENTATION. ",
            "Any person that has valid access to your computer or internal network may copy an" +
                "d use the documentation for your internal, reference purposes.",
            "",
            "6. TRANSFER TO ANOTHER DEVICE. ",
            "You may uninstall the software and install it on another device for your use. You" +
                " may not do so to share this license between devices.",
            "",
            "7. EXPORT RESTRICTIONS. ",
            resources.GetString("listBox1.Items3"),
            "",
            "8. SUPPORT SERVICES.",
            " Because this software is “as is,” we may not provide support services for it.",
            "",
            "9. ENTIRE AGREEMENT. ",
            "This agreement, and the terms for supplements, updates, Internet-based services a" +
                "nd support services that you use, are the entire agreement for the software and " +
                "support services.",
            "",
            "10. APPLICABLE LAW.",
            "",
            "United States. ",
            resources.GetString("listBox1.Items4"),
            "",
            "Outside the United States. ",
            "If you acquired the software in any other country, the laws of that country apply" +
                ".",
            "",
            "11. LEGAL EFFECT. ",
            resources.GetString("listBox1.Items5"),
            "",
            " 12. DISCLAIMER OF WARRANTY.",
            resources.GetString("listBox1.Items6"),
            "",
            "LIMITATION ON AND EXCLUSION OF REMEDIES AND DAMAGES. ",
            resources.GetString("listBox1.Items7"),
            "This limitation applies to ",
            "",
            "anything related to the software, services, content (including code) on third par" +
                "ty Internet sites, or third party programs; and",
            "",
            "claims for breach of contract, breach of warranty, guarantee or condition, strict" +
                " liability, negligence, or other tort to the extent permitted by applicable law." +
                "",
            "",
            resources.GetString("listBox1.Items8")});
            this.listBox1.Location = new System.Drawing.Point(21, 95);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(747, 420);
            this.listBox1.TabIndex = 8;
            // 
            // License_Agreement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 602);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.LicenseInfo);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.agree);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.LisenceForm);
            this.Name = "License_Agreement";
            this.Text = "License Agreement";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LisenceForm;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button agree;
        private System.Windows.Forms.Label Info;
        private System.Windows.Forms.Label LicenseInfo;
        private System.Windows.Forms.ListBox listBox1;
    }
}