﻿using System;
using System.Reflection.Emit;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Windows_11._1_Installer
{
    public partial class License_Agreement : Form
    {
        public License_Agreement()
        {
            InitializeComponent();
        }

        private void Cancel_Click(object sender, EventArgs e)
        {
            DialogResult Msg = MessageBox.Show("Do you want to proceed? The setup will not be completed.", "Confirmation", MessageBoxButtons.OKCancel, MessageBoxIcon.Information);
            if (Msg == DialogResult.OK)
            {
                this.Close();
                if (Msg == DialogResult.Cancel)
                { }
                else { }
            }
        }

        private void agree_Click(object sender, EventArgs e)
        {
            this.Close();
            Template template = new Template();
            template.Show();
        }
    }
}
