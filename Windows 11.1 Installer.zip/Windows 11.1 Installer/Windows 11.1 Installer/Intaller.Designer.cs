﻿using System.Windows.Forms;

namespace Windows_11._1_Installer
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WelcomeText = new System.Windows.Forms.Label();
            this.Cancel = new System.Windows.Forms.Button();
            this.Next = new System.Windows.Forms.Button();
            this.Info = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // WelcomeText
            // 
            this.WelcomeText.AutoSize = true;
            this.WelcomeText.Font = new System.Drawing.Font("Microsoft JhengHei Light", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WelcomeText.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.WelcomeText.Location = new System.Drawing.Point(12, 29);
            this.WelcomeText.Name = "WelcomeText";
            this.WelcomeText.Size = new System.Drawing.Size(717, 50);
            this.WelcomeText.TabIndex = 0;
            this.WelcomeText.Text = "Welcome to the Windows 11.1 Installer!";
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(30, 540);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(192, 35);
            this.Cancel.TabIndex = 1;
            this.Cancel.Text = "Exit";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            this.Cancel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Cancel_Click);
            // 
            // Next
            // 
            this.Next.Location = new System.Drawing.Point(573, 540);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(186, 35);
            this.Next.TabIndex = 2;
            this.Next.Text = "Next";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.Next_Click);
            // 
            // Info
            // 
            this.Info.AutoSize = true;
            this.Info.Font = new System.Drawing.Font("Microsoft Tai Le", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Info.ForeColor = System.Drawing.SystemColors.InfoText;
            this.Info.Location = new System.Drawing.Point(17, 79);
            this.Info.Name = "Info";
            this.Info.Size = new System.Drawing.Size(347, 22);
            this.Info.TabIndex = 3;
            this.Info.Text = "We\'re thrilled you\'re installing Windows 11.1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label1.Location = new System.Drawing.Point(25, 128);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(498, 30);
            this.label1.TabIndex = 5;
            this.label1.Text = "- This setup will guide you through the steps.";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 602);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Info);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.WelcomeText);
            this.Name = "Form1";
            this.Text = "Installer";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WelcomeText;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Label Info;
        private Label label1;
    }
}

